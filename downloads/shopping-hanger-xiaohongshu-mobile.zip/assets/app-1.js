
(function(root){
  'use strict';
  const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
  function spring(s,key,velocity,target,k,c,dt){
    s[velocity]+=((target-s[key])*k-s[velocity]*c)*dt;
    s[key]+=s[velocity]*dt;
  }
  class RackPhysics{
    constructor(){this.contacts=0;this.lastMotion=0;this.stillTime=0;}
    prepare(s){
      if(!s.fabric)s.fabric=Array.from({length:6},()=>({angle:0,av:0,yaw:s.clothYaw,yv:0}));
      if(s.mix===undefined)s.mix=s.targetYaw===0?1:0;
    }
    step(states,dt,ctx){
      states.forEach((s,i)=>{
        this.prepare(s);
        if(s.detailStatic)return;
        const held=ctx.gesture?.dragged&&(ctx.gesture.index===i||ctx.gesture.index===null);
        const target=held?ctx.gesture.origins[i]+ctx.gesture.dx:s.target;
        spring(s,'x','vx',target,held?640:66,held?42:12.8,dt);
        s.vx=clamp(s.vx,-1000,1000);
        const lean=clamp(-s.vx/Math.max(.25,ctx.scale)*.007,-4.5,4.5);
        if(s.clickRockAt&&ctx.time>=s.clickRockAt){
          s.av+=s.clickRockVelocity||0;s.clickRockAt=0;s.clickRockVelocity=0;s.rockUntil=ctx.time+1500;
        }
        const clickRock=ctx.time<(s.rockUntil||0);
        spring(s,'angle','av',lean,clickRock?30:34,clickRock?5.6:8.6,dt);
        s.angle=clamp(s.angle,-5.2,5.2);s.av=clamp(s.av,-35,35);
        spring(s,'hangerYaw','hangerVelocity',s.hangerTarget,420,40,dt);
        if(ctx.time>=s.clothStart)spring(s,'clothYaw','clothVelocity',s.targetYaw,52*(s.weight||1),9.2,dt);
        s.mix+=(s.targetYaw===0?1-s.mix:-s.mix)*(1-Math.exp(-23*dt));
        s.fabric.forEach((row,j)=>{
          const above=j?s.fabric[j-1]:{angle:s.angle,yaw:s.hangerYaw};
          spring(row,'angle','av',above.angle,145-j*15,16-j*.65,dt);
          const shoulder=s.hangerYaw+(s.targetYaw-s.hangerTarget);
          const yawTarget=j?above.yaw:shoulder*.8+s.clothYaw*.2;
          spring(row,'yaw','yv',yawTarget,190-j*18,21-j*1.1,dt);
          row.angle=clamp(row.angle,-7.2,7.2);
          row.yaw=clamp(row.yaw,-4,80);row.yv=clamp(row.yv,-230,230);
        });
      });
      this.resolve(states,ctx);
    }
    resolve(states,ctx){
      const active=states.map((s,i)=>!ctx.inRack||ctx.inRack(i));
      let bounds=states.map((s,i)=>ctx.measure?ctx.measure(i,s):{left:42,right:52});
      // 手机：选中的挂钩锁定中心槽位，两侧从中心向外解算。
      // 不再用整条链的边界回归移动中心衣服，保证邻衣能继续被选到。
      if(ctx.mobileFocus!==null&&ctx.mobileFocus!==undefined&&active[ctx.mobileFocus]){
        const focus=ctx.mobileFocus,spacing=ctx.mobileViewport*.30;
        states[focus].x=0;states[focus].vx=0;
        for(const direction of [-1,1]){
          let previous=focus;
          for(let i=focus+direction;i>=0&&i<states.length;i+=direction){
            if(!active[i])continue;
            const separation=direction>0?bounds[previous].right+bounds[i].left+9:bounds[previous].left+bounds[i].right+9;
            const gap=Math.max(spacing, separation);
            const position=ctx.base[previous]+states[previous].x+direction*gap;
            states[i].x=position-ctx.base[i];states[i].vx=0;previous=i;
          }
        }
        return;
      }
      const invMass=i=>ctx.gesture?.dragged&&ctx.gesture.index===i ? .22 : (states[i].weight||1);
      // 双向投影，多次迭代把推力传到整条链；保持原始商品顺序。
      const neighbours=states.map((_,i)=>i).filter(i=>active[i]);
      for(let pass=0;pass<48;pass++){
        for(let q=0;q<neighbours.length-1;q++){
          const k=pass%2?neighbours.length-2-q:q;
          const i=neighbours[k],j=neighbours[k+1];
          if(!active[i]||!active[j])continue;
          const a=states[i],b=states[j];
          const overlap=ctx.base[i]+a.x+bounds[i].right+3-(ctx.base[j]+b.x-bounds[j].left);
          if(overlap<=.001)continue;
          const wa=invMass(i),wb=invMass(j),sum=wa+wb;
          a.x-=overlap*wa/sum;b.x+=overlap*wb/sum;
          const relative=b.vx-a.vx;
          if(relative<0){
            const impulse=-(1.05)*relative/sum;
            a.vx-=impulse*wa;b.vx+=impulse*wb;
            const torque=clamp(impulse*.012/Math.max(.25,ctx.scale),0,7);
            a.av+=torque;b.av-=torque;
            a.fabric?.forEach((row,k)=>row.av+=torque*(k+1)/12);
            b.fabric?.forEach((row,k)=>row.av-=torque*(k+1)/12);
            this.contacts++;
          }
        }
        states.forEach((s,i)=>{
          if(!active[i])return;
          const lo=8+bounds[i].left-ctx.base[i];
          const hi=ctx.width-8-bounds[i].right-ctx.base[i];
          if(s.x<lo){s.x=lo;s.vx=Math.max(0,s.vx)*.12;s.av*=.8;}
          if(s.x>hi){s.x=hi;s.vx=Math.min(0,s.vx)*.12;s.av*=.8;}
        });
      }
      // 边界处的链式推挤使用有界等距回归收尾，避免迭代误差留下穿插。
      const span=()=>neighbours.reduce((sum,i)=>sum+bounds[i].left+bounds[i].right,0)+Math.max(0,neighbours.length-1)*3;
      for(let n=0;n<16&&span()>ctx.width-16;n++){
        neighbours.forEach(i=>{states[i].angle*=.8;states[i].av*=.8;states[i].fabric?.forEach(f=>{f.angle*=.8;f.av*=.8;});});
        bounds=states.map((s,i)=>ctx.measure?ctx.measure(i,s):bounds[i]);
      }
      if(neighbours.length){
        const prefix=[0],blocks=[];
        for(let k=1;k<neighbours.length;k++)prefix[k]=prefix[k-1]+bounds[neighbours[k-1]].right+bounds[neighbours[k]].left+3;
        neighbours.forEach((i,k)=>{
          const weight=1/invMass(i),value=ctx.base[i]+states[i].x-prefix[k];
          blocks.push({first:k,last:k,weight,total:value*weight});
          while(blocks.length>1){
            const a=blocks[blocks.length-2],b=blocks[blocks.length-1];
            if(a.total/a.weight<=b.total/b.weight)break;
            a.last=b.last;a.weight+=b.weight;a.total+=b.total;blocks.pop();
          }
        });
        const lower=8+bounds[neighbours[0]].left;
        const upper=ctx.width-8-bounds[neighbours.at(-1)].right-prefix.at(-1);
        blocks.forEach(block=>{
          const value=clamp(block.total/block.weight,lower,Math.max(lower,upper));
          for(let k=block.first;k<=block.last;k++){
            const i=neighbours[k];states[i].x=value+prefix[k]-ctx.base[i];
          }
        });
      }
      states.forEach(s=>{
        s.av=clamp(s.av,-35,35);
        s.fabric?.forEach(f=>{f.av=clamp(f.av,-45,45);});
      });
    }
    energy(states){
      return Math.max(0,...states.map(s=>Math.max(s.clickRockAt?1:0,Math.abs(s.vx)*.1,Math.abs(s.av)*.1,
        Math.abs(s.angle),Math.abs(s.hangerYaw-s.hangerTarget),Math.abs(s.clothYaw-s.targetYaw),
        Math.abs(s.clothVelocity)*.1,...(s.fabric||[]).map(f=>Math.max(Math.abs(f.angle),Math.abs(f.av)*.1,Math.abs(f.yaw-s.targetYaw),Math.abs(f.yv)*.1)))));
    }
    sleep(states){
      states.forEach(s=>{
        s.vx=s.angle=s.av=s.hangerVelocity=s.clothVelocity=0;
        s.clickRockAt=s.clickRockVelocity=s.rockUntil=0;
        s.hangerYaw=s.hangerTarget;s.clothYaw=s.targetYaw;s.mix=s.targetYaw===0?1:0;
        this.prepare(s);s.fabric.forEach(f=>{f.angle=f.av=f.yv=0;f.yaw=s.targetYaw;});
      });
    }
  }
  if(typeof module!=='undefined')module.exports=RackPhysics;
  else root.RackPhysics=RackPhysics;
})(typeof window==='undefined'?globalThis:window);

(function(root){
  'use strict';
  const RAD=Math.PI/180,ROWS=24,COLS=6;
  class RackClothRenderer{
    constructor(models,specs,states,rack,viewport,onReady){
      this.models=models;this.specs=specs;this.states=states;this.rack=rack;this.viewport=viewport;this.items=[];
      this.canvas=document.createElement('canvas');this.canvas.className='cloth-scene';this.canvas.setAttribute('aria-hidden','true');
      const gl=this.canvas.getContext('webgl',{alpha:true,antialias:true,premultipliedAlpha:true});
      if(!gl){this.available=false;return;}this.gl=gl;
      const shader=(type,source)=>{const s=gl.createShader(type);gl.shaderSource(s,source);gl.compileShader(s);if(!gl.getShaderParameter(s,gl.COMPILE_STATUS))throw Error(gl.getShaderInfoLog(s));return s;};
      const program=gl.createProgram();
      gl.attachShader(program,shader(gl.VERTEX_SHADER,'attribute vec2 a_position;attribute vec2 a_uv;attribute float a_shade;uniform vec2 u_resolution;varying vec2 v_uv;varying float v_shade;void main(){gl_Position=vec4(a_position/u_resolution*vec2(2.,-2.)+vec2(-1.,1.),0.,1.);v_uv=a_uv;v_shade=a_shade;}'));
      gl.attachShader(program,shader(gl.FRAGMENT_SHADER,'precision mediump float;uniform sampler2D u_image;uniform float u_alpha;varying vec2 v_uv;varying float v_shade;void main(){vec4 c=texture2D(u_image,v_uv);gl_FragColor=vec4(c.rgb*v_shade,c.a)*u_alpha;}'));
      gl.linkProgram(program);if(!gl.getProgramParameter(program,gl.LINK_STATUS))throw Error(gl.getProgramInfoLog(program));
      this.program=program;gl.useProgram(program);
      this.position=gl.getAttribLocation(program,'a_position');this.uv=gl.getAttribLocation(program,'a_uv');this.shade=gl.getAttribLocation(program,'a_shade');
      this.resolution=gl.getUniformLocation(program,'u_resolution');this.alpha=gl.getUniformLocation(program,'u_alpha');
      this.buffer=gl.createBuffer();this.indices=gl.createBuffer();
      const indices=[];
      for(let y=0;y<ROWS;y++)for(let x=0;x<COLS;x++){const a=y*(COLS+1)+x,b=a+COLS+1;indices.push(a,b,a+1,a+1,b,b+1);}
      this.indexData=new Uint16Array(indices);this.vertexData=new Float32Array((ROWS+1)*(COLS+1)*5);
      gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER,this.indices);gl.bufferData(gl.ELEMENT_ARRAY_BUFFER,this.indexData,gl.STATIC_DRAW);
      gl.enable(gl.BLEND);gl.blendFunc(gl.ONE,gl.ONE_MINUS_SRC_ALPHA);gl.pixelStorei(gl.UNPACK_PREMULTIPLY_ALPHA_WEBGL,true);
      document.body.append(this.canvas);this.available=true;
      models.forEach((model,i)=>{
        const entry={};this.items.push(entry);
        for(const [key,selector] of [['front','.garment-front'],['side','.garment-side'],['hanger','.hanger']]){
          const image=model.querySelector(selector);
          const upload=()=>{
            if(!image.naturalWidth)return;
            const texture=gl.createTexture();gl.bindTexture(gl.TEXTURE_2D,texture);
            gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_S,gl.CLAMP_TO_EDGE);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_WRAP_T,gl.CLAMP_TO_EDGE);
            gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MIN_FILTER,gl.LINEAR);gl.texParameteri(gl.TEXTURE_2D,gl.TEXTURE_MAG_FILTER,gl.LINEAR);
            gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,gl.RGBA,gl.UNSIGNED_BYTE,image);
            const points=[];let hitAlpha=null;
            if(key!=='hanger'){
              const c=document.createElement('canvas');c.width=96;c.height=160;const cx=c.getContext('2d',{willReadFrequently:true});cx.drawImage(image,0,0,96,160);
              const alpha=cx.getImageData(0,0,96,160).data;hitAlpha=alpha;
              for(let row=0;row<=ROWS;row++){
                const y=Math.min(159,Math.round(row/ROWS*159));let lo=96,hi=-1;
                for(let yy=Math.max(0,y-3);yy<=Math.min(159,y+3);yy++)for(let x=0;x<96;x++)if(alpha[(yy*96+x)*4+3]>10){lo=Math.min(lo,x);hi=Math.max(hi,x);}
                if(hi>=lo)points.push([lo/96,row/ROWS],[(hi+1)/96,row/ROWS]);
              }
            }
            entry[key]={texture,points,hitAlpha,ratio:image.naturalHeight/image.naturalWidth};
            if(this.items.every(it=>it.front&&it.side&&it.hanger))document.body.classList.add('mesh-ready');
            onReady();
          };
          if(image.complete)upload();else image.addEventListener('load',upload,{once:true});
        }
      });
      this.canvas.addEventListener('webglcontextlost',e=>{e.preventDefault();this.available=false;document.body.classList.remove('mesh-ready');});
      this.canvas.addEventListener('webglcontextrestored',()=>{location.reload();});
    }
    row(s,v){
      if(!s.fabric)return {angle:s.angle,yaw:s.clothYaw};
      const p=Math.max(0,Math.min(5,v*5)),a=Math.floor(p),b=Math.min(5,a+1),t=p-a;
      return {angle:s.fabric[a].angle*(1-t)+s.fabric[b].angle*t,yaw:s.fabric[a].yaw*(1-t)+s.fabric[b].yaw*t};
    }
    point(i,key,u,v){
      const spec=this.specs[i],s=this.states[i];let width,height,top,anchor;
      if(key==='hanger'){width=spec.hanger;height=spec.hangerHeight||width*(this.items[i].hanger?.ratio||.43);top=25-width*(spec.hangerHookY||35)/420;anchor=.5;}
      else{const pose=spec[key];height=pose.displayHeight||spec.height;width=height*pose.width/pose.height;top=pose.top;anchor=pose.anchor;}
      // 正面悬挂图包含衣架：金属钩和木肩保持刚性，布料从支撑点以下逐渐自由。
      const pin=key==='side'?.19:key==='front'?(spec.front.clothStartV??.025):1;
      let free=key==='hanger'?0:Math.max(0,Math.min(1,(v-pin)/(1-pin)));
      free=free*free*(3-2*free);
      const fabric=this.row(s,free),angle=(s.angle*(1-free)+fabric.angle*free)*RAD;
      const x=(u-anchor)*width;
      if(key==='hanger'){
        const yaw=s.hangerYaw*RAD,z=-x*Math.sin(yaw),perspective=1400/(1400+z);
        const xx=x*Math.cos(yaw)*perspective,yy=top+v*height-25;
        return {x:140+xx*Math.cos(angle)-yy*Math.sin(angle),y:25+xx*Math.sin(angle)+yy*Math.cos(angle),shade:1};
      }
      // 照片已经提供正面/侧挂造型，不再把整张照片按绝对转角挤窄。
      // 只显示肩部与各段衣身之间的小幅相对扭转，形变集中在两边和衣摆。
      const shoulder=s.hangerYaw+(s.targetYaw-s.hangerTarget);
      const lag=Math.max(-16,Math.min(16,fabric.yaw-shoulder));
      const rigidTurn=key==='front'&&spec.frontIntegrated?
        Math.max(-70,Math.min(70,s.hangerYaw-s.hangerTarget))*Math.pow(1-free,3):0;
      const torsion=lag/16*free,yaw=(lag*free+rigidTurn)*RAD;
      const z=-x*Math.sin(yaw),perspective=1800/(1800+z);
      const sidePhase=Math.sin((u-anchor)*Math.PI);
      const trail=width*.028*torsion*free;
      const edgeCurl=width*.026*torsion*sidePhase;
      const xx=x*Math.cos(yaw)*perspective+trail;
      const yy=top+v*height-25+edgeCurl;
      return {x:140+xx*Math.cos(angle)-yy*Math.sin(angle),y:25+xx*Math.sin(angle)+yy*Math.cos(angle),shade:1-Math.min(.045,Math.abs(torsion)*.03)*(0.45+sidePhase*.35)};
    }
    measure(i,scale){
      const item=this.items[i],s=this.states[i];let lo=0,hi=0;
      if(!item?.side||!item.front)return null;
      for(const key of ['side','front']){
        if(key==='front'&&s.mix<.025||key==='side'&&s.mix>.975)continue;
        item[key].points.forEach(([u,v])=>{const p=this.point(i,key,u,v).x-140;lo=Math.min(lo,p);hi=Math.max(hi,p);});
      }
      if(s.mix>.05&&!this.specs[i].frontIntegrated)for(const u of [0,1]){const p=this.point(i,'hanger',u,.55).x-140;lo=Math.min(lo,p);hi=Math.max(hi,p);}
      return {left:-lo*scale+2,right:hi*scale+2};
    }
    drawItem(i,key,box,alpha){
      const item=this.items[i][key];if(!item||alpha<.003)return;
      const scale=box.width/280,gl=this.gl;let n=0;
      for(let row=0;row<=ROWS;row++)for(let col=0;col<=COLS;col++){
        const u=col/COLS,v=row/ROWS,p=this.point(i,key,u,v);
        this.vertexData[n++]=box.left+p.x*scale;this.vertexData[n++]=box.top+p.y*scale;
        this.vertexData[n++]=u;this.vertexData[n++]=v;this.vertexData[n++]=p.shade;
      }
      gl.bindBuffer(gl.ARRAY_BUFFER,this.buffer);gl.bufferData(gl.ARRAY_BUFFER,this.vertexData,gl.DYNAMIC_DRAW);
      for(const [loc,size,offset] of [[this.position,2,0],[this.uv,2,8],[this.shade,1,16]]){gl.enableVertexAttribArray(loc);gl.vertexAttribPointer(loc,size,gl.FLOAT,false,20,offset);}
      gl.bindTexture(gl.TEXTURE_2D,item.texture);gl.uniform1f(this.alpha,alpha);gl.drawElements(gl.TRIANGLES,this.indexData.length,gl.UNSIGNED_SHORT,0);
    }
    hitTest(x,y,activeIndex){
      const vp=this.viewport.getBoundingClientRect();
      if(x<vp.left||x>vp.right||y<vp.top||y>vp.bottom)return null;
      const order=this.models.map((_,i)=>i).sort((a,b)=>(a===activeIndex?1:0)-(b===activeIndex?1:0)||a-b).reverse();
      for(const i of order){
        if(this.models[i].parentElement!==this.rack[i])continue;
        const box=this.models[i].getBoundingClientRect(),scale=box.width/280,state=this.states[i];
        const px=(x-box.left)/scale,py=(y-box.top)/scale;
        for(const key of ['front','side']){
          if(key==='front'&&state.mix<.1||key==='side'&&state.mix>.9)continue;
          const item=this.items[i]?.[key];if(!item?.hitAlpha)continue;
          const vertices=[];
          for(let r=0;r<=ROWS;r++)for(let c=0;c<=COLS;c++)vertices.push({...this.point(i,key,c/COLS,r/ROWS),u:c/COLS,v:r/ROWS});
          for(let t=0;t<this.indexData.length;t+=3){
            const a=vertices[this.indexData[t]],b=vertices[this.indexData[t+1]],c=vertices[this.indexData[t+2]];
            const den=(b.y-c.y)*(a.x-c.x)+(c.x-b.x)*(a.y-c.y);if(Math.abs(den)<1e-8)continue;
            const wa=((b.y-c.y)*(px-c.x)+(c.x-b.x)*(py-c.y))/den;
            const wb=((c.y-a.y)*(px-c.x)+(a.x-c.x)*(py-c.y))/den,wc=1-wa-wb;
            if(wa<0||wb<0||wc<0)continue;
            const u=a.u*wa+b.u*wb+c.u*wc,v=a.v*wa+b.v*wb+c.v*wc;
            const ix=Math.max(0,Math.min(95,Math.floor(u*96))),iy=Math.max(0,Math.min(159,Math.floor(v*160)));
            if(item.hitAlpha[(iy*96+ix)*4+3]>40)return i;
          }
        }
      }
      return null;
    }
    render(collection,mode,activeIndex){
      if(!this.available)return;
      const gl=this.gl,dpr=Math.min(devicePixelRatio||1,2),width=innerWidth,height=innerHeight;
      if(this.canvas.width!==Math.round(width*dpr)||this.canvas.height!==Math.round(height*dpr)){this.canvas.width=Math.round(width*dpr);this.canvas.height=Math.round(height*dpr);}
      gl.viewport(0,0,this.canvas.width,this.canvas.height);gl.clearColor(0,0,0,0);gl.disable(gl.SCISSOR_TEST);gl.clear(gl.COLOR_BUFFER_BIT);
      gl.useProgram(this.program);gl.uniform2f(this.resolution,width,height);
      this.canvas.style.zIndex=mode==='rack'?'4':'11';
      const fade=Number(getComputedStyle(collection).opacity),vp=this.viewport.getBoundingClientRect();
      const order=this.models.map((_,i)=>i).sort((a,b)=>{
        const da=this.models[a].parentElement!==this.rack[a],db=this.models[b].parentElement!==this.rack[b];
        return Number(da)-Number(db)||(a===activeIndex?1:0)-(b===activeIndex?1:0)||a-b;
      });
      for(const i of order){
        const model=this.models[i],onRack=model.parentElement===this.rack[i],box=model.getBoundingClientRect(),s=this.states[i];
        const alpha=(onRack?fade:1)*Number(getComputedStyle(model).opacity);if(box.width===0||alpha<.003)continue;
        if(onRack){gl.enable(gl.SCISSOR_TEST);gl.scissor(0,Math.max(0,Math.floor((height-vp.bottom)*dpr)),this.canvas.width,Math.min(this.canvas.height,Math.ceil(vp.height*dpr)));}else gl.disable(gl.SCISSOR_TEST);
        if(!this.specs[i].frontIntegrated&&!this.specs[i].clip)this.drawItem(i,'hanger',box,alpha*s.mix);
        this.drawItem(i,'side',box,alpha*(1-s.mix));this.drawItem(i,'front',box,alpha*s.mix);
        if(!this.specs[i].frontIntegrated&&this.specs[i].clip)this.drawItem(i,'hanger',box,alpha*s.mix);
      }
      gl.disable(gl.SCISSOR_TEST);
    }
  }
  root.RackClothRenderer=RackClothRenderer;
})(window);

'use strict';
const ARCHIVE_ASSETS={"assets/clip-hanger.svg": "./assets/svg-2.svg", "assets/hanger.svg": "./assets/svg-3.svg", "assets/skirt-hanger.svg": "./assets/svg-4.svg", "assets/halter-hanger.svg": "./assets/svg-5.svg", "assets/favicon.svg": "./assets/svg-1.svg"};

// 一款一个衣架。默认侧挂，悬停只显示品名；拖拽在原架拨正，轻点查看详情。
const PRODUCTS = [
  {id:'floral-dress',name:'花间 · 飘袖连衣裙',originalName:'奶油白V领飘袖花卉装饰连衣裙',english:'The Bloom Dress',description:'奶油白的轻柔裙身，\nV 领与飘袖，\n把花朵留在身边。',front:"./assets/webp-1.webp",frontGenerated:true,side:"./assets/webp-2.webp",sideGenerated:true,kind:'dress',frontWidth:100,sideWidth:90},
  {id:'sage-camisole',name:'青序 · 蕾丝吊带上衣',originalName:'浅绿缎面蕾丝拼接抽绳吊带上衣',english:'The Sage Camisole',description:'一抹清浅的绿，\n蕾丝拼接与抽绳细节，\n让日常多一点轻盈。',front:"./assets/webp-3.webp",frontGenerated:true,side:"./assets/webp-4.webp",sideGenerated:true,kind:'top',frontWidth:88,sideWidth:77},
  {id:'lace-slip',name:'暮色 · 蕾丝吊带长裙',originalName:'缎面吊带长裙（黑蕾丝胸口）',english:'The Afterglow Slip',description:'垂落的缎面裙身，\n黑色蕾丝勾勒领口，\n细节，自有分寸。',front:"./assets/webp-5.webp",frontGenerated:true,side:"./assets/webp-6.webp",sideGenerated:true,kind:'slip',frontWidth:82,sideWidth:73},
  {id:'ivory-gown',name:'月白 · 抹胸褶皱长裙',originalName:'奶油白抹胸褶皱长礼服',english:'The Ivory Gown',description:'柔和的奶油白，\n抹胸与自然褶皱，\n留住安静的轮廓。',front:"./assets/webp-7.webp",frontGenerated:true,side:"./assets/webp-8.webp",sideGenerated:true,kind:'gown'},
  {id:'black-lace-slip',name:'夜曲 · 蕾丝吊带裙',originalName:'黑色蕾丝不对称吊带裙',english:'The Nocturne Slip',front:"./assets/webp-9.webp",frontGenerated:true,side:"./assets/webp-10.webp",sideGenerated:true,kind:'slip'},
  {id:'cocoa-halter',name:'可可 · 垂领挂脖上衣',originalName:'棕色垂领挂脖上衣',english:'The Cocoa Halter',front:"./assets/webp-11.webp",frontGenerated:true,side:"./assets/webp-12.webp",sideGenerated:true,kind:'top'},
  {id:'ivory-knit',name:'绵云 · 针织开衫',originalName:'奶油白长袖针织开衫',english:'The Cloud Cardigan',front:"./assets/webp-13.webp",frontGenerated:true,side:"./assets/webp-14.webp",sideGenerated:true,kind:'top'},
  {id:'ivory-drape-top',name:'流光 · 垂褶上衣',originalName:'奶油白不对称垂褶上衣',english:'The Drape Top',front:"./assets/webp-15.webp",frontGenerated:true,side:"./assets/webp-16.webp",sideGenerated:true,kind:'top'},
  {id:'lace-bow-cami',name:'花笺 · 蕾丝系带吊带',originalName:'奶油白黑蕾丝系带吊带上衣',english:'The Ribbon Camisole',front:"./assets/webp-17.webp",frontGenerated:true,side:"./assets/webp-18.webp",sideGenerated:true,kind:'top'},
  {id:'ivory-wrap-skirt',name:'微风 · 系带裹身短裙',originalName:'奶油白侧系带裹身短裙',english:'The Breeze Skirt',front:"./assets/webp-19.webp",frontGenerated:true,side:"./assets/webp-20.webp",sideGenerated:true,kind:'skirt'}
];
const SUSPENSION = [
  {height:350,hanger:136,yaw:82,front:{width:736,height:1120,anchor:.5,top:43},side:{width:622,height:1400,anchor:.592,top:47}},
  {height:250,hanger:119,yaw:82,tilt:10,front:{width:614,height:899,anchor:.5,top:48},side:{width:594,height:1371,anchor:.631,top:49}},
  {height:415,hanger:63,yaw:75,front:{width:467,height:1400,anchor:.5,top:31},side:{width:367,height:1353,anchor:.51,top:28}},
  {height:405,hanger:158,yaw:42,clip:true,front:{width:336,height:1036,anchor:.5,top:62},side:{width:393,height:1333,anchor:.511,top:55}},
  {height:360,hanger:87.1,yaw:74,front:{width:551,height:1286,anchor:258/551,top:38.6}},
  {height:255,hanger:75.2,yaw:74,hangerAsset:'halter-hanger',front:{width:227,height:389,anchor:108/227,top:20.9}},
  {height:295,hanger:130.6,yaw:74,front:{width:905,height:1400,anchor:455/905,top:37.5}},
  {height:255,hanger:108.9,yaw:74,front:{width:1009,height:1142,anchor:402/1009,top:43}},
  {height:260,hanger:159.6,yaw:74,front:{width:663,height:1021,anchor:331/663,top:58.9}},
  {height:275,hanger:196.8,yaw:74,clip:true,hangerAsset:'skirt-hanger',front:{width:875,height:1041,anchor:424/875,top:81.1}}
];
const HANGING_GEOMETRY=[{"width":1008,"height":1560,"anchor":0.5188492063492064,"top":10.305343511450381,"displayHeight":416.793893129771,"leftExtent":47.02,"rightExtent":56.11},{"width":989,"height":1591,"anchor":0.5136501516683518,"top":10.328638497652582,"displayHeight":311.2284820031299,"leftExtent":36.38,"rightExtent":43.43},{"width":1008,"height":1560,"anchor":0.5059523809523809,"top":12.078204199855179,"displayHeight":468.79073135409124,"leftExtent":42.97,"rightExtent":52.59},{"width":1008,"height":1560,"anchor":0.5138888888888888,"top":10.132158590308372,"displayHeight":463.8766519823788,"leftExtent":44.31,"rightExtent":52.93},{"width":1024,"height":1536,"anchor":0.498046875,"top":13.819875776397517,"displayHeight":429.31677018633536,"leftExtent":35.5,"rightExtent":62.89},{"width":1008,"height":1560,"anchor":0.5059523809523809,"top":14.074373484236055,"displayHeight":321.5844785772029,"leftExtent":34.22,"rightExtent":45.56},{"width":1008,"height":1560,"anchor":0.5109126984126984,"top":11.63141993957704,"displayHeight":347.58308157099697,"leftExtent":38.1,"rightExtent":40.33},{"width":1008,"height":1560,"anchor":0.5079365079365079,"top":14.034401876465989,"displayHeight":311.02423768569196,"leftExtent":34.09,"rightExtent":47.85},{"width":1008,"height":1560,"anchor":0.5059523809523809,"top":14.482200647249192,"displayHeight":328.15533980582524,"leftExtent":32.39,"rightExtent":50.7},{"width":1008,"height":1560,"anchor":0.503968253968254,"top":8.808876811594203,"displayHeight":388.5869565217391,"leftExtent":67.01,"rightExtent":74.98}];
// 正面与侧挂图均自带真实衣架；固定挂钩与可见下摆，保持同一场景比例。
const FRONT_HANGING_GEOMETRY=[{"width":1017,"height":1547,"anchor":0.5034414945919371,"top":13.72460283293258,"displayHeight":415.3104623203166,"embeddedHanger":true,"clothStartV":0.16160310277957338},{"width":1036,"height":1518,"anchor":0.5057915057915058,"top":15.835610200364298,"displayHeight":302.4248633879782,"embeddedHanger":true,"clothStartV":0.2898550724637681},{"width":724,"height":2171,"anchor":0.4972375690607735,"top":16.46469054495695,"displayHeight":463.2539206724614,"embeddedHanger":true,"clothStartV":0.1312759097190235},{"width":928,"height":1695,"anchor":0.5053879310344828,"top":12.79962425498834,"displayHeight":459.54748639543925,"embeddedHanger":true,"clothStartV":0.09793510324483776},{"width":821,"height":1916,"anchor":0.4993909866017052,"top":15.408646287323716,"displayHeight":427.3728770578549,"embeddedHanger":true,"clothStartV":0.18006263048016702},{"width":958,"height":1642,"anchor":0.4989561586638831,"top":14.249186835625814,"displayHeight":320.9606402891348,"embeddedHanger":true,"clothStartV":0.2740560292326431},{"width":1008,"height":1560,"anchor":0.5109126984126984,"top":15.334084410269883,"displayHeight":342.70064363588597,"embeddedHanger":true,"clothStartV":0.1987179487179487},{"width":1179,"height":1334,"anchor":0.46140797285835455,"top":14.570015250156759,"displayHeight":316.218174006611,"embeddedHanger":true,"clothStartV":0.25487256371814093},{"width":1010,"height":1557,"anchor":0.5,"top":15.06154172635153,"displayHeight":336.39520721892757,"embeddedHanger":true,"clothStartV":0.2729608220937701},{"width":1150,"height":1368,"anchor":0.508695652173913,"top":8.829250257201647,"displayHeight":356.7997685185185,"embeddedHanger":true,"clothStartV":0.266812865497076}];
SUSPENSION.forEach((spec,index)=>{spec.front=FRONT_HANGING_GEOMETRY[index];spec.side=HANGING_GEOMETRY[index];spec.frontIntegrated=true;});
// 每张侧挂图包含自己的衣架，按挂钩接触点对齐金属杆。
const hangingBottom=spec=>Math.max(spec.front.top+(spec.front.displayHeight||spec.height),spec.side.top+(spec.side.displayHeight||spec.height));
const sceneHeight=Math.max(480,...SUSPENSION.map(hangingBottom));
const swayAngle=index=>1+(index%3)*.2;
const swayRoom=index=>(hangingBottom(SUSPENSION[index])-25)*Math.sin(swayAngle(index)*Math.PI/180);
const edgeSpan=Math.max(HANGING_GEOMETRY[0].leftExtent+swayRoom(0),HANGING_GEOMETRY.at(-1).rightExtent+swayRoom(PRODUCTS.length-1));
const pairSpan=Math.max(...HANGING_GEOMETRY.slice(0,-1).map((pose,index)=>pose.rightExtent+HANGING_GEOMETRY[index+1].leftExtent+swayRoom(index)+swayRoom(index+1)));
const $ = selector => document.querySelector(selector);
const collection = $('#collection-view');
const detail = $('#detail-view');
const detailStage = $('#detail-stage');
const detailProduct = $('#detail-product');
const rack = $('#garment-rack');
const scene = $('#rack-scene');
const footer = $('#site-footer');
const motionPreference = matchMedia('(prefers-reduced-motion: reduce)');
const DISPLAY = PRODUCTS.map((_,index)=>index);
const models = [];
const rackItems = [];
const animations = new Set();
let activeIndex = 0;
let activeView = 'front';
let detailOpen = false;
let mode = 'rack';
let hoverIndex = null;
let focusIndex = null;
let suppressFocus = false;
let selectedInquiry = 0;
let homeScale = 1;
let detailScale = 1;
let slotSpacing = 96;
let motionEpoch = 0;
let pointerStart = null;

// 第二版：衣架先转正，衣身带扭转惯性慢半拍跟随。
// 挂钩摆角只用于邻衣联动；选中款不再施加整件左右摇摆。
const garmentDynamics=[];
let reactionFrame=0;
let reactionTime=0;
let lastRackChoice=null;
const rackPhysics=new RackPhysics();
let clothRenderer=null;
let rackGesture=null;
let rackPreviewIndex=null;
let ignoreHoverUntil=0;
let lastInputTime=0;
let quietTime=0;
let dragClickUntil=0;
function physicsContext(time){
  return {time,scale:homeScale,width:scene.clientWidth,gesture:rackGesture,
    mobileFocus:innerWidth<=700&&mode==='rack'?rackPreviewIndex:null,
    mobileViewport:innerWidth<=700?rackViewport.clientWidth:0,
    base:PRODUCTS.map((_,i)=>scene.clientWidth/2+(i-(PRODUCTS.length-1)/2)*slotSpacing),
    inRack:i=>models[i].parentElement===rackItems[i],
    measure:(i,state)=>clothRenderer?.measure(i,homeScale)||{
      left:Math.max(HANGING_GEOMETRY[i].leftExtent*homeScale,Math.abs(Math.sin(state.angle*Math.PI/180))*SUSPENSION[i].height*homeScale+20),
      right:Math.max(HANGING_GEOMETRY[i].rightExtent*homeScale,Math.abs(Math.sin(state.angle*Math.PI/180))*SUSPENSION[i].height*homeScale+20)
    }};
}
function springStep(state,key,velocity,target,stiffness,damping,dt){
  state[velocity]+=((target-state[key])*stiffness-state[velocity]*damping)*dt;
  state[key]+=state[velocity]*dt;
  if(Math.abs(state[key]-target)<.008&&Math.abs(state[velocity])<.025){state[key]=target;state[velocity]=0;}
}
function drawReaction(index){
  const state=garmentDynamics[index];
  rackItems[index].style.setProperty('--shift',`${state.x.toFixed(3)}px`);
  state.pivot.style.transform=`rotate(${state.angle.toFixed(3)}deg)`;
  // 两个独立转角：木衣架的回正已完成时，衣身仍保留角度与速度。
  models[index].style.setProperty('--suspension-yaw',`${state.hangerYaw.toFixed(3)}deg`);
  models[index].style.setProperty('--cloth-yaw',`${state.clothYaw.toFixed(3)}deg`);
  const lag=Math.max(-16,Math.min(16,state.clothYaw-state.hangerYaw));
  models[index].style.setProperty('--cloth-torsion',`${(lag*.55).toFixed(3)}deg`);
  const shear=state.targetYaw===0?lag*-.025:0;
  models[index].style.setProperty('--cloth-shear',`${shear.toFixed(3)}deg`);
}
function settleReactions(){
  cancelAnimationFrame(reactionFrame);reactionFrame=0;reactionTime=0;
  garmentDynamics.forEach((state,index)=>{
    state.x=state.target;state.vx=state.angle=state.av=0;
    state.hangerYaw=state.hangerTarget;state.hangerVelocity=0;
    state.clothYaw=state.targetYaw;state.clothVelocity=0;state.clothStart=0;
    drawReaction(index);
  });
  rackPhysics.sleep(garmentDynamics);
  rackPhysics.resolve(garmentDynamics,physicsContext(performance.now()));
  garmentDynamics.forEach((_,i)=>drawReaction(i));
  clothRenderer?.render(collection,mode,rackPreviewIndex??activeIndex);
}
function tickReactions(time){
  if(motionPreference.matches){settleReactions();return;}
  const dt=reactionTime?Math.min((time-reactionTime)/1000,.1):1/60;
  reactionTime=time;
  const steps=Math.max(1,Math.ceil(dt*120)),step=dt/steps;
  for(let n=0;n<steps;n++)rackPhysics.step(garmentDynamics,step,physicsContext(time-dt*1000+(n+1)*step*1000));
  garmentDynamics.forEach((_,i)=>drawReaction(i));
  clothRenderer?.render(collection,mode,rackPreviewIndex??activeIndex);
  const energy=rackPhysics.energy(garmentDynamics);
  quietTime=energy<.16?quietTime+dt:0;
  const travelling=!['rack','detail'].includes(mode);
  if(!rackGesture?.dragged&&!travelling&&(quietTime>.35||time-lastInputTime>4200)){
    rackPhysics.sleep(garmentDynamics);
    rackPhysics.resolve(garmentDynamics,physicsContext(time));
    garmentDynamics.forEach((_,i)=>drawReaction(i));
    clothRenderer?.render(collection,mode,rackPreviewIndex??activeIndex);
    reactionFrame=0;reactionTime=0;return;
  }
  reactionFrame=requestAnimationFrame(tickReactions);
}
function wakeReactions(){
  lastInputTime=performance.now();quietTime=0;
  if(motionPreference.matches){settleReactions();return;}
  if(!reactionFrame){reactionTime=0;reactionFrame=requestAnimationFrame(tickReactions);}
}
function straightenGarment(index,direction=1){
  if(motionPreference.matches)return;
  const state=garmentDynamics[index],now=performance.now();
  // 拖拽原架预览或轻点详情时施加拨正力，随后小幅回摆。
  if(state.hangerYaw>8)state.hangerVelocity=Math.min(state.hangerVelocity,-220);
  state.clothStart=now+80;
  state.clickRockAt=now+260;
  state.clickRockVelocity=direction*16;
  wakeReactions();
}
function nudgeNeighbours(){
  // 邻居由接触约束和碰撞冲量带动，不再按预设顺序播放摆动。
  wakeReactions();
}

function announce(message){ $('#live-status').textContent = message; }
function applySuspension(model,index){
  const spec = SUSPENSION[index];
  model.style.setProperty('--hanger-width',`${spec.hanger}px`);
  model.style.setProperty('--hanger-height',`${spec.hangerHeight}px`);
  model.style.setProperty('--hanger-top',`${25-spec.hanger*(spec.hangerHookY||35)/420}px`);
  // 侧面照片统一以前襟朝右陈列；正面照片保留原始图案方向。
  model.style.setProperty('--hanger-yaw',`${-spec.yaw}deg`);
  model.style.setProperty('--hanger-tilt',`${-(spec.tilt||0)}deg`);
  model.classList.toggle('clip-suspension',!!spec.clip);
  model.classList.toggle('integrated-side',!!PRODUCTS[index].sideGenerated);
  model.classList.toggle('integrated-front',!!spec.frontIntegrated);
  if(PRODUCTS[index].sideGenerated)model.style.setProperty('--hanger-yaw','78deg');
  model.classList.toggle('projected-side',!PRODUCTS[index].side);
  if(!PRODUCTS[index].side)model.style.setProperty('--hanger-yaw','74deg');
  for(const view of ['front','side']){
    const pose = spec[view];
    const height = pose.displayHeight||spec.height;
    const width = height*pose.width/pose.height;
    model.style.setProperty(`--${view}-height`,`${height}px`);
    model.style.setProperty(`--${view}-width`,`${width}px`);
    model.style.setProperty(`--${view}-top`,`${pose.top}px`);
    model.style.setProperty(`--${view}-offset`,`${(.5-pose.anchor)*width}px`);
    model.style.setProperty(`--${view}-origin`,`${pose.anchor*100}% ${25-pose.top}px`);
  }
}
function setView(model,view){
  const previous=model.dataset.view;
  model.classList.toggle('is-front',view==='front');
  model.dataset.view = view;
  const state=garmentDynamics[Number(model.dataset.product)];
  if(state&&previous!==view){
    state.hangerTarget=view==='front'?0:78;
    state.targetYaw=view==='front'?0:76;
    state.clothStart=performance.now()+(view==='front'?110:0);
    if(view==='side'){state.clickRockAt=0;state.clickRockVelocity=0;state.rockUntil=0;}
    wakeReactions();
  }
}
function setStaticDetailView(index,view){
  const model=models[index],state=garmentDynamics[index];
  setView(model,view);
  state.detailStatic=true;
  state.x=state.target=state.vx=state.angle=state.av=0;
  state.hangerYaw=state.hangerTarget;state.hangerVelocity=0;
  state.clothYaw=state.targetYaw;state.clothVelocity=0;state.clothStart=0;
  state.clickRockAt=state.clickRockVelocity=state.rockUntil=0;
  state.mix=view==='front'?1:0;
  rackPhysics.prepare(state);
  state.fabric.forEach(row=>{row.angle=row.av=row.yv=0;row.yaw=state.targetYaw;});
  drawReaction(index);
}
function positionModel(model,host,scale,isHome=false){
  model.style.left = `${host.clientWidth/2-140*scale}px`;
  model.style.top = `${isHome?25*(1-scale):0}px`;
  model.style.transform = `scale(${scale})`;
}
function returnModel(index){
  const model = models[index];
  garmentDynamics[index].detailStatic=false;
  rackItems[index].prepend(model);
  setView(model,'side');
  positionModel(model,rackItems[index],homeScale,true);
}
function restoreOtherModels(keepIndex){
  models.forEach((model,index)=>{if(index!==keepIndex)returnModel(index);});
}
function updateLayout(){
  const viewport=$('#rack-viewport');
  const mobile=window.innerWidth<=700;
  const verticalScale=Math.min(1.02,Math.max(.38,(viewport.clientHeight-36)/sceneHeight));
  const intervals=PRODUCTS.length-1;
  const edgePadding=18;
  const airGap=14;
  const horizontalScale=(viewport.clientWidth*.9-edgePadding*2-intervals*airGap)/(intervals*pairSpan+edgeSpan*2);
  homeScale=mobile?Math.min(verticalScale,.58,viewport.clientWidth/740):Math.min(verticalScale,Math.max(.28,horizontalScale));
  const comfortableWidth=intervals*(pairSpan*homeScale+airGap)+2*(edgeSpan*homeScale+edgePadding);
  const sceneWidth=mobile?intervals*(viewport.clientWidth*.30)+viewport.clientWidth:viewport.clientWidth*.9;
  const gutter=Math.max(20,(viewport.clientWidth-sceneWidth)/2);
  scene.style.width=`${sceneWidth}px`;
  scene.style.marginLeft=`${gutter}px`;
  scene.style.marginRight=`${gutter}px`;
  slotSpacing=mobile?viewport.clientWidth*.30:(scene.clientWidth-2*(edgeSpan*homeScale+edgePadding))/(PRODUCTS.length-1);
  rackItems.forEach((item,index)=>{
    item.style.left = `${scene.clientWidth/2+(index-(PRODUCTS.length-1)/2)*slotSpacing}px`;
    item.style.setProperty('--hit-width',`${slotSpacing}px`);
    item.style.height = `${hangingBottom(SUSPENSION[index])*homeScale+36}px`;
    item.style.setProperty('--label-top',`${hangingBottom(SUSPENSION[index])*homeScale+13}px`);
    if(models[index].parentElement===item)positionModel(models[index],item,homeScale,true);
  });
  if(!detail.hidden)detailScale = Math.min(1.18,Math.max(.3,(detailStage.clientHeight-12)/sceneHeight),window.innerWidth/320);
  if(detailOpen && mode==='detail')positionModel(models[activeIndex],detailProduct,detailScale);
  updateRackFocus();
  wakeReactions();
}
function updateRackFocus(){
  const chosen=mode==='rack'?(rackGesture?.dragged&&rackGesture.index!==null?rackGesture.index:(hoverIndex??focusIndex)):
    (['opening','detail','switching'].includes(mode)?activeIndex:null);
  const viewing=mode==='rack'?rackPreviewIndex:(['opening','detail','switching'].includes(mode)?activeIndex:null);
  const changed=viewing!==lastRackChoice;
  rackItems.forEach((item,index)=>{
    const selected=index===chosen;
    const distance=viewing===null?0:Math.abs(index-viewing);
    const spread=viewing===null||index===viewing?0:Math.sign(index-viewing)*Math.min(innerWidth<=700?18:58,slotSpacing*.58)/(1+(distance-1)*.42);
    garmentDynamics[index].target=spread;
    const preview=mode==='rack'&&index===rackPreviewIndex;
    const pose=SUSPENSION[index].front;
    const frontWidth=(pose.displayHeight||SUSPENSION[index].height)*pose.width/pose.height*homeScale;
    item.style.setProperty('--active-width',`${preview?Math.max(slotSpacing,frontWidth+12):slotSpacing}px`);
    item.classList.toggle('is-selected',(selected||preview)&&mode==='rack');
    if(models[index].parentElement===item)setView(models[index],preview?'front':'side');
  });
  if(changed&&viewing!==null)nudgeNeighbours(viewing);
  lastRackChoice=viewing;
  // 悬停和键盘焦点只显示品名，保持侧挂并且不唤醒受力模拟。
  if(changed||mode!=='rack'||rackGesture?.dragged)wakeReactions();
}
function clearRackPreview(){
  if(rackPreviewIndex===null)return;
  rackPreviewIndex=null;hoverIndex=null;focusIndex=null;
  updateRackFocus();
  announce('已恢复侧挂全景。');
}
DISPLAY.forEach((index,i)=>{
  const product = PRODUCTS[index];
  const item = document.createElement('button');
  item.className = 'rack-item';
  item.dataset.product = index;
  item.style.setProperty('--layer',String(i+1));
  item.setAttribute('aria-label',`${product.name}，查看详情`);
  const model = document.createElement('span');
  model.className = 'garment-model';
  model.dataset.product = index;
  model.setAttribute('aria-hidden','true');
  model.style.setProperty('--breeze',`${6.6+(i%4)*.55+(SUSPENSION[index].height>350?.8:0)}s`);
  model.style.setProperty('--sway',`${swayAngle(i)}deg`);
  model.style.setProperty('--delay',`${-i*1.37}s`);
  model.innerHTML = `<span class="garment-reaction"><span class="garment-pose"><span class="garment-turn"><img class="hanger" src="${ARCHIVE_ASSETS['assets/'+(SUSPENSION[index].hangerAsset||(SUSPENSION[index].clip?'clip-hanger':'hanger'))+'.svg']}" alt="" draggable="false"><img class="garment-image garment-side" src="${product.side||product.front}" alt="" draggable="false"><img class="garment-image garment-front" src="${product.front}" alt="" draggable="false"></span></span></span>`;
  applySuspension(model,index);
  const label = document.createElement('span');
  label.className = 'product-tag';
  label.innerHTML = `${product.name}<small>${product.english}</small>`;
  item.append(model,label);
  item.addEventListener('pointerenter',e=>{if(e.pointerType==='mouse'&&mode==='rack'&&!rackGesture?.dragged&&performance.now()>ignoreHoverUntil){hoverIndex=index;updateRackFocus();}});
  item.addEventListener('pointerleave',()=>{if(hoverIndex===index&&!rackGesture?.dragged){hoverIndex=null;updateRackFocus();}});
  item.addEventListener('focus',()=>{if(!suppressFocus&&item.matches(':focus-visible')){focusIndex=index;updateRackFocus();}});
  item.addEventListener('blur',()=>{if(focusIndex===index){focusIndex=null;updateRackFocus();}});
  item.addEventListener('click',e=>{if(performance.now()<dragClickUntil){e.preventDefault();return;}openDetail(index);});
  rack.appendChild(item);
  rackItems.push(item);
  models.push(model);
  garmentDynamics.push({x:0,vx:0,target:0,angle:0,av:0,
    weight:SUSPENSION[index].height>350?.86:1,
    hangerYaw:78,hangerVelocity:0,hangerTarget:78,
    clothYaw:76,clothVelocity:0,targetYaw:76,clothStart:0,
    pivot:model.querySelector('.garment-reaction')});
  for(const view of ['front','side']){if(product[view]){const image=new Image();image.src=product[view];}}
});

// 一套网格材质渲染器，沿肩部→衣摆分六段跟随；无需GLB或额外服装模型。
try {clothRenderer=new RackClothRenderer(models,SUSPENSION,garmentDynamics,rackItems,$('#rack-viewport'),wakeReactions);}
catch(error){console.warn('布料网格不可用，保留静态服装图片。',error);}
const rackViewport=$('#rack-viewport');
const rackGestureSurface=collection;
rackGestureSurface.addEventListener('pointerdown',e=>{
  if(mode!=='rack'||e.button>0||!e.isPrimary)return;
  if(e.target.closest('a,button')&&!e.target.closest('.rack-item'))return;
  const hit=innerWidth<=700?clothRenderer?.hitTest(e.clientX,e.clientY,rackPreviewIndex):null;
  const button=innerWidth<=700?(hit===null||hit===undefined?null:rackItems[hit]):e.target.closest('.rack-item');
  if(innerWidth<=700&&!button)return;
  rackGesture={id:e.pointerId,index:button?Number(button.dataset.product):null,start:e.clientX,startY:e.clientY,last:e.clientX,
    lastTime:performance.now(),velocity:0,dx:0,dragged:false,pan:false,startScroll:rackViewport.scrollLeft,origins:garmentDynamics.map(s=>s.x)};
  rackGestureSurface.setPointerCapture(e.pointerId);
});
rackGestureSurface.addEventListener('pointermove',e=>{
  const g=rackGesture;if(!g||g.id!==e.pointerId)return;
  const now=performance.now(),elapsed=Math.max(8,now-g.lastTime),delta=e.clientX-g.last;
  g.velocity=g.velocity*.45+delta/elapsed*1000*.55;g.last=e.clientX;g.lastTime=now;
  const distance=g.index===null?Math.abs(e.clientX-g.start):Math.hypot(e.clientX-g.start,e.clientY-g.startY);
  if(!g.dragged&&distance>6){
    g.dragged=true;collection.classList.add('is-dragging');
    if(g.index!==null)rackPreviewIndex=g.index;
    updateRackFocus();
    if(g.index!==null){
      straightenGarment(g.index,e.clientX<g.start?-1:1);
      announce(`${PRODUCTS[g.index].name}，在衣架上拨正预览；轻点可查看详情。`);
    }
  }
  if(!g.dragged)return;
  e.preventDefault();g.dx=g.pan?0:e.clientX-g.start;
  if(g.pan){rackViewport.scrollLeft=g.startScroll-(e.clientX-g.start);/* 空白处仅平移视口，不拨动衣物。 */}

  if(motionPreference.matches&&!g.pan){
    garmentDynamics.forEach((s,i)=>{if(g.index===null||g.index===i)s.x=g.origins[i]+g.dx;});
    rackPhysics.resolve(garmentDynamics,physicsContext(now));
    garmentDynamics.forEach((_,i)=>drawReaction(i));clothRenderer?.render(collection,mode,rackPreviewIndex??activeIndex);
  }else wakeReactions();
});
function releaseRackGesture(cancelled=false){
  const g=rackGesture;if(!g)return;rackGesture=null;collection.classList.remove('is-dragging');
  if(!g.dragged){
    if(innerWidth<=700)dragClickUntil=performance.now()+450;
    if(!cancelled&&g.index!==null){dragClickUntil=performance.now()+100;openDetail(g.index);}
    else if(!cancelled)clearRackPreview();
    return;
  }
  dragClickUntil=performance.now()+450;ignoreHoverUntil=performance.now()+450;
  if(cancelled&&rackPreviewIndex===g.index)rackPreviewIndex=null;
  if(!cancelled&&innerWidth<=700&&g.index!==null){
    // 只拨正用户实际拖动的这件。邻衣始终侧挂，留给下一次手势。
    rackPreviewIndex=g.index;hoverIndex=null;focusIndex=null;
    updateRackFocus();
    rackPhysics.resolve(garmentDynamics,physicsContext(performance.now()));
    garmentDynamics.forEach((_,i)=>drawReaction(i));
    centerMobileGarment(g.index);
    garmentDynamics.forEach(state=>{state.vx*=.2;});
  }

  if(!cancelled&&innerWidth>700&&!motionPreference.matches){
    const stale=performance.now()-g.lastTime>100;
    const velocity=stale?0:Math.max(-950,Math.min(950,g.velocity));
    garmentDynamics.forEach((s,i)=>{
      if(g.index===null||g.index===i){s.vx=Math.max(-1000,Math.min(1000,s.vx+velocity*.6));s.av-=velocity*.009/Math.max(.3,homeScale);}
    });
  }
  hoverIndex=null;focusIndex=null;updateRackFocus();
  announce(rackPreviewIndex===null?'已松手，衣架与衣物随余力停稳。':'已松手，保留原架正面预览；轻点衣服查看详情，点空白处恢复侧挂。');
}
rackGestureSurface.addEventListener('pointerup',()=>releaseRackGesture());
rackGestureSurface.addEventListener('pointercancel',()=>releaseRackGesture(true));
rackGestureSurface.addEventListener('lostpointercapture',()=>releaseRackGesture(true));
rackViewport.addEventListener('scroll',()=>clothRenderer?.render(collection,mode,rackPreviewIndex??activeIndex),{passive:true});

// 同一个服装节点从衣架移到前景，返回时再放回自己的槽位。
// 所有新动作取消上一段动画，异步完成回调用 epoch 防止覆盖新状态。
function cancelMotion(){
  motionEpoch++;
  animations.forEach(animation=>animation.cancel());
  animations.clear();
  return motionEpoch;
}
function animate(model,keyframes,duration=560){
  if(motionPreference.matches)return null;
  const animation=model.animate(keyframes,{duration,easing:'cubic-bezier(.22,.72,.24,1)',fill:'both'});
  animations.add(animation);
  return animation;
}
async function settle(list){
  await Promise.allSettled(list.filter(Boolean).map(animation=>animation.finished));
}
function release(list){
  list.filter(Boolean).forEach(animation=>{animation.cancel();animations.delete(animation);});
}
function renderProduct(){
  const product=PRODUCTS[activeIndex];
  $('#detail-name').textContent=product.name;
  $('#detail-english').textContent=product.english;
  $('#detail-number').innerHTML=`${String(activeIndex+1).padStart(2,'0')} <i>/</i> ${String(PRODUCTS.length).padStart(2,'0')}`;
  ['front','side'].forEach(view=>{
    $(`#${view}-view`).classList.toggle('active',activeView===view);
    $(`#${view}-view`).setAttribute('aria-pressed',String(activeView===view));
  });
  $('#side-view').disabled=!product.side;
  $('#side-view').innerHTML=product.sideGenerated?'侧挂 <small>HANGING</small>':(product.side?'侧面 <small>SIDE</small>':'侧面待补');
  setStaticDetailView(activeIndex,activeView);
  announce(`第 ${activeIndex+1} 款，共 ${PRODUCTS.length} 款。${product.name}，${activeView==='front'?'正面':'自然侧挂'}`);
}
async function openDetail(index){
  if(mode!=='rack')return;
  const epoch=cancelMotion();
  const model=models[index];
  const from=model.getBoundingClientRect();
  activeIndex=index;
  rackPreviewIndex=null;
  activeView='front';
  detailOpen=true;
  mode='opening';
  nudgeNeighbours(index,1.1);
  detail.hidden=false;
  detail.setAttribute('aria-hidden','false');
  detail.classList.remove('is-leaving');
  $('#detail-footer-mount').appendChild(footer);
  detailProduct.appendChild(model);
  updateLayout();
  positionModel(model,detailProduct,detailScale);
  const to=model.getBoundingClientRect();
  const flight=animate(model,[
    {transform:`translate(${from.left-to.left}px,${from.top-to.top}px) scale(${from.width/280})`},
    {transform:`translate(0,0) scale(${detailScale})`}
  ]);
  renderProduct();
  hoverIndex=null;
  focusIndex=null;
  updateRackFocus();
  document.body.classList.add('detail-open');
  collection.inert=true;
  collection.setAttribute('aria-hidden','true');
  $('.site-header').inert=true;
  $('#detail-name').focus({preventScroll:true});
  await settle([flight]);
  if(epoch!==motionEpoch)return;
  release([flight]);
  mode='detail';
}
function homeRect(index){
  const bounds=scene.getBoundingClientRect();
  return {left:bounds.left+scene.clientWidth/2+(index-(PRODUCTS.length-1)/2)*slotSpacing-140*homeScale,top:bounds.top+25*(1-homeScale)};
}
function revealHomeSlot(index){
  const viewport=$('#rack-viewport');
  const bounds=viewport.getBoundingClientRect();
  const center=homeRect(index).left+140*homeScale;
  if(center<bounds.left+80||center>bounds.right-80)viewport.scrollLeft+=center-bounds.left-bounds.width/2;
}
async function closeDetail(){
  if(!detailOpen||mode==='closing')return;
  const model=models[activeIndex];
  const from=model.getBoundingClientRect();
  const epoch=cancelMotion();
  restoreOtherModels(activeIndex);
  mode='closing';
  garmentDynamics[activeIndex].detailStatic=false;
  detailOpen=false;
  hoverIndex=null;
  focusIndex=null;
  updateRackFocus();
  revealHomeSlot(activeIndex);
  positionModel(model,detailProduct,detailScale);
  const base=model.getBoundingClientRect();
  const to=homeRect(activeIndex);
  detail.classList.add('is-leaving');
  document.body.classList.remove('detail-open');
  setView(model,'side');
  const flight=animate(model,[
    {transform:`translate(${from.left-base.left}px,${from.top-base.top}px) scale(${from.width/280})`,opacity:1},
    {transform:`translate(${to.left-base.left}px,${to.top-base.top}px) scale(${homeScale})`,opacity:1}
  ]);
  await settle([flight]);
  if(epoch!==motionEpoch)return;
  returnModel(activeIndex);
  release([flight]);
  detail.hidden=true;
  detail.setAttribute('aria-hidden','true');
  detail.classList.remove('is-leaving');
  $('#footer-mount').appendChild(footer);
  collection.inert=false;
  collection.removeAttribute('aria-hidden');
  $('.site-header').inert=false;
  mode='rack';
  suppressFocus=true;
  rackItems[activeIndex].focus({preventScroll:true});
  suppressFocus=false;
  announce(`已返回衣架全景。${PRODUCTS[activeIndex].name}`);
}
async function switchProduct(index,direction){
  if(mode!=='detail'&&mode!=='switching')return;
  index=(index+PRODUCTS.length)%PRODUCTS.length;
  if(index===activeIndex)return;
  const previousIndex=activeIndex;
  const previous=models[previousIndex];
  const from=previous.getBoundingClientRect();
  const epoch=cancelMotion();
  restoreOtherModels(previousIndex);
  mode='switching';
  direction=direction??(index>activeIndex?1:-1);
  activeIndex=index;
  activeView='front';
  const current=models[index];
  detailProduct.appendChild(current);
  positionModel(previous,detailProduct,detailScale);
  positionModel(current,detailProduct,detailScale);
  const base=previous.getBoundingClientRect();
  renderProduct();
  updateRackFocus();
  const outgoing=animate(previous,[
    {transform:`translate(${from.left-base.left}px,${from.top-base.top}px) scale(${from.width/280})`,opacity:1},
    {transform:`translate(${-direction*60}px,0) scale(${detailScale*.98})`,opacity:0}
  ],300);
  const incoming=animate(current,[
    {transform:`translate(${direction*60}px,0) scale(${detailScale*.98})`,opacity:0},
    {transform:`translate(0,0) scale(${detailScale})`,opacity:1}
  ],380);
  await settle([outgoing,incoming]);
  if(epoch!==motionEpoch)return;
  returnModel(previousIndex);
  release([outgoing,incoming]);
  mode='detail';
}
function switchView(view){
  if(!detailOpen||mode==='opening'||mode==='closing'||activeView===view)return;
  if(view==='side'&&!PRODUCTS[activeIndex].side)return;
  activeView=view;
  renderProduct();
}
$('#previous-product').addEventListener('click',()=>switchProduct(activeIndex-1,-1));
$('#next-product').addEventListener('click',()=>switchProduct(activeIndex+1,1));
$('#front-view').addEventListener('click',()=>switchView('front'));
$('#side-view').addEventListener('click',()=>switchView('side'));
$('#detail-close-button').addEventListener('click',closeDetail);
$('.brand').addEventListener('click',e=>{e.preventDefault();closeDetail();});

// 全景横向滑动衣架，轻点进入；详情横滑切款，纵向触摸交给浏览器。
detailStage.addEventListener('pointerdown',e=>{
  if(e.target.closest('button')||e.button>0||!e.isPrimary)return;
  pointerStart={x:e.clientX,y:e.clientY,id:e.pointerId};
  detailStage.setPointerCapture(e.pointerId);
});
detailStage.addEventListener('pointerup',e=>{
  if(!pointerStart||e.pointerId!==pointerStart.id)return;
  const dx=e.clientX-pointerStart.x,dy=e.clientY-pointerStart.y;
  pointerStart=null;
  if(Math.abs(dx)>45&&Math.abs(dx)>Math.abs(dy)*1.3)switchProduct(activeIndex+(dx<0?1:-1),dx<0?1:-1);
});
detailStage.addEventListener('pointercancel',()=>pointerStart=null);
detailStage.addEventListener('lostpointercapture',()=>pointerStart=null);
document.addEventListener('keydown',e=>{
  if(document.querySelector('dialog[open]'))return;
  if(e.key==='Escape'&&mode==='rack'&&rackPreviewIndex!==null){e.preventDefault();clearRackPreview();return;}
  if(!detailOpen)return;
  if(e.key==='ArrowLeft'){e.preventDefault();switchProduct(activeIndex-1,-1);}
  if(e.key==='ArrowRight'){e.preventDefault();switchProduct(activeIndex+1,1);}
  if(e.key==='Escape'){e.preventDefault();closeDetail();}
  if(e.key==='Tab'){
    const controls=[...detail.querySelectorAll('button:not([disabled])')].filter(button=>button.getClientRects().length);
    const first=controls[0],last=controls[controls.length-1];
    if(e.shiftKey&&(document.activeElement===first||document.activeElement===$('#detail-name'))){e.preventDefault();last.focus();}
    else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
  }
});

PRODUCTS.forEach((product,index)=>{
  const item=document.createElement('button');
  item.className='availability-item';
  item.dataset.index=index;
  item.setAttribute('aria-pressed','false');
  item.innerHTML=`<img src="${product.front}" alt=""><span><strong>${product.name}</strong><small>${product.english} · 库存待确认</small></span><i class="selection-circle" aria-hidden="true"></i>`;
  item.addEventListener('click',()=>selectInquiry(index));
  $('#availability-list').appendChild(item);
});
const INFO={
  about:{eyebrow:'A LITTLE ABOUT US / 关于衣间',title:'把逛小店的心情，带回来。',html:'<p>衣间 · Shopping Hanger，是一个可以慢慢挑衣服的线上小衣间。</p><p>十件衣服，安静地侧挂在杆上。移近看看品名，拖动喜欢的那一件，衣架带着衣身在原架回正，两侧轻轻让开；轻点，再细看。让衣服的轮廓、褶皱与细节，自己说话。</p><p>愿你找到的那一件，也能给平常的日子添一点喜欢。</p><p class="dialog-signature">Take your time.<br>Shopping Hanger ✳</p>'},
  contact:{eyebrow:'LET’S TALK / 联系衣间',title:'关于喜欢的那一件。',html:'<p>想询问尺码、库存或更多细节？先在「SEE AVAILABILITY」中选中款式，复制询款信息，再发送给店主。</p><div class="contact-placeholder">店铺联系方式尚未填写。<br>正式营业前，将在这里补充联系方式。</div>'}
};
function openInfo(key){const data=INFO[key];$('#dialog-eyebrow').textContent=data.eyebrow;$('#dialog-title').textContent=data.title;$('#dialog-content').innerHTML=data.html;$('#info-dialog').showModal();}
$('#about-button').addEventListener('click',()=>openInfo('about'));
$('#contact-button').addEventListener('click',()=>openInfo('contact'));
document.querySelectorAll('dialog').forEach(dialog=>{
  dialog.querySelector('.dialog-close').addEventListener('click',()=>dialog.close());
  dialog.addEventListener('click',e=>{if(e.target!==dialog)return;const b=dialog.getBoundingClientRect();if(e.clientX<b.left||e.clientX>b.right||e.clientY<b.top||e.clientY>b.bottom)dialog.close();});
});
function selectInquiry(index){
  selectedInquiry=index;
  document.querySelectorAll('.availability-item').forEach((item,i)=>{item.classList.toggle('active',i===index);item.setAttribute('aria-pressed',String(i===index));});
  $('#availability-status').textContent=`已选择：${PRODUCTS[index].name}`;
  $('.inquiry-fallback')?.remove();
  $('#copy-inquiry').innerHTML='复制询款信息 <span aria-hidden="true">↗</span>';
}
$('#availability-button').addEventListener('click',()=>{selectInquiry(detailOpen?activeIndex:(rackPreviewIndex??selectedInquiry));$('#availability-dialog').showModal();});
$('#copy-inquiry').addEventListener('click',async()=>{
  const product=PRODUCTS[selectedInquiry];
  const text=`你好，我想咨询「${product.name}」\n款式：${product.originalName}\n请问目前有哪些尺码及库存？谢谢。`;
  try{
    if(!navigator.clipboard?.writeText)throw new Error('clipboard unavailable');
    await navigator.clipboard.writeText(text);
    $('#copy-inquiry').textContent='已复制 ✓';
    $('#availability-status').textContent='询款信息已复制，可以发送给店主。';
  }catch{
    $('.inquiry-fallback')?.remove();
    const field=document.createElement('textarea');field.className='inquiry-fallback';field.setAttribute('aria-label','询款信息，长按或全选复制');field.readOnly=true;field.value=text;$('#copy-inquiry').after(field);field.focus();field.select();$('#availability-status').textContent='请全选并复制上方询款信息。';
  }
});


let resizeFrame;
window.addEventListener('resize',()=>{
  cancelAnimationFrame(resizeFrame);
  resizeFrame=requestAnimationFrame(()=>{
    if(mode==='opening'||mode==='switching'){
      cancelMotion();
      restoreOtherModels(activeIndex);
      mode='detail';
    }else if(mode==='closing'){
      // 关闭中的目标坐标随视口变化重算。
      mode='detail';
      detailOpen=true;
      updateLayout();
      closeDetail();
      return;
    }
    updateLayout();
  });
});
motionPreference.addEventListener('change',()=>{
  if(motionPreference.matches)settleReactions();
  if(mode==='opening'||mode==='switching'){
    cancelMotion();restoreOtherModels(activeIndex);mode='detail';updateLayout();
  }
});
updateLayout();

document.addEventListener('visibilitychange',()=>{
  if(document.hidden){cancelAnimationFrame(reactionFrame);reactionFrame=0;reactionTime=0;}
  else wakeReactions();
});

window.addEventListener('scroll',()=>clothRenderer?.render(collection,mode,rackPreviewIndex??activeIndex),{passive:true});


function centerMobileGarment(index,instant=false){
  if(innerWidth>700||mode!=='rack')return;
  const viewportWidth=rackViewport.clientWidth;
  const anchor=scene.offsetLeft+parseFloat(rackItems[index].style.left)+(garmentDynamics[index].x||0);
  rackViewport.scrollTo({left:anchor-viewportWidth/2,behavior:instant||motionPreference.matches?'instant':'smooth'});
}
// 让两端也有足够空间停在中央；首尾款仅有一侧相邻商品。
if(innerWidth<=700)centerMobileGarment(DISPLAY[1]??DISPLAY[0],true);
window.addEventListener('resize',()=>{if(innerWidth<=700)requestAnimationFrame(()=>centerMobileGarment(rackPreviewIndex??DISPLAY[1]??DISPLAY[0],true))});

const rackBrowser=document.createElement('div');rackBrowser.className='rack-browser';
rackBrowser.innerHTML='<span>浏览衣架</span><input type="range" min="0" max="1000" step="1" value="0" aria-label="横向浏览整排衣服"><span class="rack-browser-count">01 / 10</span>';
collection.appendChild(rackBrowser);
const rackRange=rackBrowser.querySelector('input'),rackCount=rackBrowser.querySelector('.rack-browser-count');
function syncRackRange(){
 const max=Math.max(0,rackViewport.scrollWidth-rackViewport.clientWidth);
 rackRange.value=String(max?rackViewport.scrollLeft/max*1000:0);
 const rect=rackViewport.getBoundingClientRect(),mid=rect.left+rect.width/2;
 let best=0,distance=Infinity;
 rackItems.forEach((item,i)=>{const b=item.getBoundingClientRect(),d=Math.abs(b.left+b.width/2-mid);if(d<distance){distance=d;best=i}});
 rackCount.textContent=String(best+1).padStart(2,'0')+' / '+String(PRODUCTS.length).padStart(2,'0');
}
rackRange.addEventListener('pointerdown',e=>e.stopPropagation());
rackRange.addEventListener('input',()=>{
 if(mode!=='rack')return;
 clearRackPreview();
 rackViewport.scrollTo({left:Number(rackRange.value)/1000*Math.max(0,rackViewport.scrollWidth-rackViewport.clientWidth),behavior:'instant'});
 syncRackRange();
});
rackViewport.addEventListener('scroll',syncRackRange,{passive:true});
window.addEventListener('resize',()=>requestAnimationFrame(syncRackRange));syncRackRange();
