
(()=>{
'use strict';
const button=document.createElement('button');button.id='shopping-music';button.type='button';button.textContent='♫ 音乐';button.setAttribute('aria-label','开启背景音乐');button.setAttribute('aria-pressed','false');
Object.assign(button.style,{position:'fixed',right:'14px',top:'104px',zIndex:35,border:'1px solid #b8bdad',borderRadius:'20px',padding:'8px 12px',background:'#f4f1e8ed',color:'#657058',fontSize:'11px',minHeight:'36px'});document.body.append(button);
let ctx,bus,timer,next=0,beat=0,enabled=false,touched=false;const step=60/86/2;
const chords=[[57,60,64,67],[53,57,60,64],[48,52,55,59],[55,59,62,65]];
function note(midi,time,duration,gain,type='sine'){
 const osc=ctx.createOscillator(),amp=ctx.createGain();osc.type=type;osc.frequency.value=440*Math.pow(2,(midi-69)/12);
 amp.gain.setValueAtTime(0,time);amp.gain.linearRampToValueAtTime(gain,time+.02);amp.gain.exponentialRampToValueAtTime(.0001,time+duration);
 osc.connect(amp);amp.connect(bus);osc.start(time);osc.stop(time+duration+.06);osc.onended=()=>{osc.disconnect();amp.disconnect()};
}
function tick(){
 while(next<ctx.currentTime+.18){
  const chord=chords[Math.floor(beat/16)%4],n=beat%16;
  if(n===0)chord.forEach((m,j)=>note(m,next+j*.025,3,.10));
  if(n%4===0)note(chord[0]-12,next,.55,.13);
  if(n%2===0)note(chord[[0,2,1,3,2,1,3,2][Math.floor(n/2)]]+12,next,1.05,.065);
  if(n===6||n===14)note(chord[3]+12,next,.75,.035);
  beat++;next+=step;
 }
}
function label(){button.textContent=enabled?'♫ 音乐开':'♫ 音乐关';button.setAttribute('aria-pressed',String(enabled));button.setAttribute('aria-label',enabled?'关闭背景音乐':'开启背景音乐')}
async function play(){
 try{
  if(!ctx){const AC=window.AudioContext||window.webkitAudioContext;if(!AC){button.textContent='音乐暂不可用';return}ctx=new AC();bus=ctx.createGain();bus.gain.value=.22;const compressor=ctx.createDynamicsCompressor();bus.connect(compressor);compressor.connect(ctx.destination);}
  await ctx.resume();if(ctx.state!=='running')return;enabled=true;next=ctx.currentTime+.06;clearInterval(timer);tick();timer=setInterval(tick,70);label();
 }catch(e){enabled=false;label()}
}
function pause(){enabled=false;clearInterval(timer);ctx?.suspend();label()}
button.addEventListener('click',e=>{e.stopPropagation();touched=true;enabled?pause():play()});
document.addEventListener('pointerdown',e=>{if(!touched&&!button.contains(e.target)){touched=true;play()}},{passive:true});
document.addEventListener('visibilitychange',()=>{if(document.hidden){clearInterval(timer);ctx?.suspend()}else if(enabled)play()});
window.addEventListener('pagehide',()=>{clearInterval(timer);ctx?.suspend()});
})();

